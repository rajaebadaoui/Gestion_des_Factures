<?php

	/*=======================================================
	=> Gestion des employés : Ajouter | Modifier | Supprimer
	=======================================================*/

	session_start();

	$pageTitle = 'Gestion des Employés';

	include_once 'initialize.php';

	if (!isset($_SESSION['Login'])) {

		header('Location: login.php');
		exit();

	} else {

		$do = isset($_GET['do']) ? $_GET['do'] : '';

		if (!isset($_GET['do']) || $do == '' || $do == 'Manage') {

			// Get Clients
			$employees = getEmployees();

?>

			<div class="container text-center title dashboard">
				
				<div class="row">

					<h1 class="text-center">Gestion des Employés</h1>

					<div class="table-responsive">

						<table class="main-table table table-bordered manage-members text-center">

							<tr>
								<td>#</td>
								<td>Login</td>
								<td>Nom complet</td>
								<td>CIN</td>
								<td>Téléphone</td>
								<td>Ville</td>
								<td>Code postal</td>
								<td>Date d'ajout</td>
								<td>Rôle</td>
								<td>Contrôle</td>
							</tr>

							<?php
								foreach ($employees as $employee) {

									echo '<tr>';
										echo '<td class="text-center">' . $employee['Emp_ID'] 	. '</td>';
										echo '<td class="text-center">' . $employee['Login'] 	. '</td>';
										echo '<td class="text-center">' . $employee['Emp_Name'] . '</td>';
										echo '<td class="text-center">' . $employee['Emp_CIN']	. '</td>';
										echo '<td class="text-center">' . $employee['Emp_Phone']. '</td>';
										echo '<td class="text-center">' . $employee['Emp_City'] . '</td>';
										echo '<td class="text-center">' . $employee['Emp_Zip_Code'] . '</td>';
										echo '<td class="text-center">' . $employee['Add_Date'] . '</td>';

										echo '<td class="text-center">';

											if($employee['Is_Admin']){

												echo '<span class="label label-danger"><i class="fa fa-user-secret fa-fw"></i> Administrateur</span>';

											} else {

												echo '<span class="label label-success"><i class="fa fa-user fa-fw"></i> Modérateur</span>';

											}

										echo '</td>';

										// Start Buttons
										echo '<td>';
											echo " <a href='employees.php?do=Edit&Emp_ID=" . $employee['Emp_ID'] . " ' class='btn btn-success'><i class='fa fa-edit'></i> Modifier</a>
												  <a href='employees.php?do=Delete&Emp_ID=" . $employee['Emp_ID'] . " ' class='btn btn-danger confirm'><i class='fa fa-user-times'></i> Supprimer</a>";
										echo "</td>";
										// End Buttons

									echo '</tr>';

								}
							?>

						</table>

					</div>

					<!-- Add New Client Button -->
					<div class="text-left">
						<a href="employees.php?do=Add" class="btn btn-primary"><i class="fa fa-user-plus"></i> Ajouter Employé</a>
						<a href="index.php" class="btn btn-warning"><i class="fas fa-undo"></i> Retour</a>
					</div>

				</div>

			</div>

<?php

		} elseif ($do == 'Add') {

?>

			<h1 class="text-center">Nouveau employé</h1>

			<div class="container">

				<div class="col-md-2"></div>

				<div class="col-md-8">

					<div class="panel panel-primary item-infos">

						<div class="panel-heading">Informations d'employé</div>

						<div class="panel-body">

							<div class="row">

								<div class="col-md-12">

									<form class="form-horizontal" method="POST" action="?do=Insert">

										<!-- Start FullName Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="fullname">Nom complet</label>
											<div class="col-sm-10 col-md-6">
												<input  type 		= "text"
														name 		= "fullname"
														id 			= "fullname"
														class 		= "form-control"
														placeholder = "Nom complet"
														required 	= "required"/>
											</div>
										</div>
										<!-- End FullName Field -->

										<!-- Start CIN Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="cin">CIN</label>
											<div class="col-sm-10 col-md-6">
												<input 	type 		= "text"
														name 		= "cin"
														id 			= "cin"
														class 		= "form-control"
														placeholder = "Carte d'identité nationale"
														required 	= "required"/>
											</div>
										</div>
										<!-- End CIN Field -->

										<!-- Start Phone Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="phone">Téléphone</label>
											<div class="col-sm-10 col-md-6">
												<input  type 		= "number"
														min 		= "0"
														name 		= "phone"
														id 			= "phone"
														class 		= "form-control"
														placeholder = "Téléphone mobile"
														required 	= "required"/>
											</div>
										</div>
										<!-- End Phone Field -->

										<!-- Start Address Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="address">Adresse</label>
											<div class="col-sm-10 col-md-6">
												<input  type 		= "text"
														name 		= "address"
														id 			= "address"
														class 		= "form-control"
														placeholder = "Adresse"
														required 	= "required"/>
											</div>
										</div>
										<!-- End Address Field -->

										<!-- Start City / Postal Code Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="city">Ville</label>
											<div class="col-sm-10 col-md-3">
												<select name="city" id="city">
													<option value="0">. . .</option>
														<?php
														
															$cities = ['Agadir', 'Al Hoceïma',
																		'Béni Mellal',
																		'Casablanca',
																		'El Jadida', 'Errachidia',
																		'Fès',
																		'Kénitra', 'Khénifra', 'Khouribga',
																		'Larache',
																		'Marrakech', 'Martin', 'Mdiq', 'Meknès',
																		'Nador',
																		'Ouarzazate', 'Oujda',
																		'Rabat',
																		'Safi', 'Settat', 'Salé',
																		'Tanger', 'Taza', 'Tétouan'];

	    													foreach ($cities as $city) {
																echo "<option value='". $city ."'>". $city ."</option>";
															}

														?>
												</select>
											</div>

											<div class="col-sm-10 col-md-3">
												<input  type 		= "number"
														min 		= "0"
														name 		= "zipcode"
														id 			= "zipcode"
														class 		= "form-control"
														placeholder = "Code postal"
														required 	= "required"/>
											</div>

										</div>
										<!-- End City / Postal Code Field -->

										<!-- Start Login Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="login">Login</label>
											<div class="col-sm-10 col-md-6">
												<input  type 		= "text"
														name 		= "login"
														id 			= "login"
														class 		= "form-control"
														placeholder = "Nom d'utilisateur"
														required 	= "required"/>
											</div>
										</div>
										<!-- End Login Field -->

										<!-- Start Password Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="password">Mot de passe</label>
											<div class="col-sm-10 col-md-6">
												<input type="password" name="password" id="password" class="form-control" autocomplete="new-password" placeholder="Mot de passe" required="required"/>
											</div>
										</div>

										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="confirm">Confirmation</label>
											<div class="col-sm-10 col-md-6">
												<input type="password" name="confirm" id="confirm" class="form-control" autocomplete="new-password" placeholder="Confirmation de mot de passe" required="required"/>
											</div>
										</div>
										<!-- End Password Field -->

										<!-- Start Role Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label">Rôle</label>
											<div class="col-sm-10 col-md-6">
												<div>
													<input type="radio" name="role" id="admin" value="1" checked="">
													<label for="admin">Administrateur</label>
												</div>
												<div>
													<input type="radio" name="role" id="mod" value="0">
													<label for="mod">Modérateur</label>
												</div>
											</div>
										</div>
										<!-- End Role Field -->

										<!-- Start Submit Button Field -->
										<div class="form-group form-group-lg">
											<div class="col-sm-offset-4 col-sm-10">
												<input  type  = "submit"
														value = "Valider"
														class = "btn btn-primary btn-md"/>

												<input  type  = "reset"
														value = "Réinitialiser"
														class = "btn btn-danger btn-md"/>

												<a href="<?php echo $_SERVER['HTTP_REFERER']; ?>" class="btn btn-default btn-md">Annuler</a>
											</div>
										</div>
										<!-- End Submit Button Field -->
								
									</form>

								</div>

							</div>

						</div>

					</div>

				</div>

			</div>
<?php

		} elseif ($do == 'Insert') {

			if ($_SERVER['REQUEST_METHOD'] == 'POST'){

				echo "<h1 class='text-center'>Insertion du nouveau client</h1>";

				echo "<div class='container'>";

					// Get variables from the Form
					$fullname 	= filter_var($_POST['fullname']	, FILTER_SANITIZE_STRING);
					$cin 		= filter_var($_POST['cin']		, FILTER_SANITIZE_STRING);
					$phone 		= filter_var($_POST['phone']	, FILTER_SANITIZE_NUMBER_INT);
					$address 	= filter_var($_POST['address']	, FILTER_SANITIZE_STRING);
					$city 		= filter_var($_POST['city']		, FILTER_SANITIZE_STRING);
					$zipcode 	= filter_var($_POST['zipcode']	, FILTER_SANITIZE_NUMBER_INT);
					$login 		= filter_var($_POST['login']	, FILTER_SANITIZE_STRING);
					$password 	= filter_var($_POST['password']	, FILTER_SANITIZE_STRING);
					$confirm 	= filter_var($_POST['confirm']	, FILTER_SANITIZE_STRING);
					$role 		= $_POST['role'];

					// Validate the Form : conditions
					$formErrors = array();

					// Check if a Client (with this CIN) already exist in database
					if (checkExistence("CIN", "clients", $cin)) {
						$formErrors[] = "Il y a déjà un compte avec <strong>le numéro de CIN entré</strong>.";
					}

					if (checkExistence("Login", "employees", $login)) {
						$formErrors[] = "Il y a déjà un compte avec <strong>le nom d'utilisateur entré</strong>.";
					}

					if (strlen($password) < 6) {
						$formErrors[] = "Le mot de passe doit contenir <strong>au moins 6 caractères</strong>.";
					}

					if (strlen($fullname) < 4) {
						$formErrors[] = "Le nom doit contenir <strong>au moins 4 caractères</strong>.";
					}

					if (empty($cin)) {
						$formErrors[] = "Le champ CIN est <strong>obligatoire</strong>";
					}

					if (strlen($phone) < 10) {
						$formErrors[] = "Le numéro de téléphone doit contenir <strong>au moins 10 chiffres</strong>.";
					}

					if (empty($address)) {
						$formErrors[] = "Le champ Adresse est <strong>obligatoire</strong>.";
					}

					if ($city == '0') {
						$formErrors[] = "Le champ Ville est <strong>obligatoire</strong>.";
					}

					if (empty($zipcode)) {
						$formErrors[] = "Le champ Code Postal est <strong>obligatoire</strong>.";
					}

					// Loop into Errors array
					if (!empty($formErrors)) {

						echo "<div class='alert alert-danger'>";

							foreach($formErrors as $error) {
								echo "<p><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> " . $error ."</p>";
							}

						echo "</div>";

						echo "<div class='alert alert-info'>";
							echo "<i class='fa fa-info-circle' aria-hidden='true'></i> ";
							echo "Retournez vers la page précédente pour compléter l’insertion du client.";
						echo "</div>";
					
					} else {

						// Insert Client Informations_____________________________________________________________
						$insertClient = $con->prepare("INSERT INTO clients(Fullname,
																   CIN,
																   Address,
																   City,
																   Zip_Code,
																   Phone,
																   `Date`,
																   Emp_ID)
														VALUES(:Fullname,
															   :CIN,
															   :Address,
															   :City,
															   :Zip_Code,
															   :Phone,
															   now(),
															   :Emp_ID)");
						
						$insertClient->execute(array('Fullname' => $fullname,
													 'CIN'		=> $cin,
													 'Address'	=> $address,
													 'City'		=> $city,
													 'Zip_Code'	=> $zipcode,
													 'Phone'	=> $phone,
													 'Emp_ID' 	=> $_SESSION['Emp_ID']));

						// Success message________________________________________________________________________
						$Msgs[] = '<div class="alert alert-success"><i class="fa fa-check-circle" aria-hidden="true"></i> ' . $insertClient->rowCount() . ' Enregistrement inséré!</div>';
						redirectHome($Msgs, 'clients', 3);

					}

				echo "</div>";

			} else { // Error message : Direct browse_________________________________________________________________

				echo "<h1 class='text-center'>Erreur : Accès direct</h1>";

				echo "<div class='container'>";

					$Msgs[] = "<div class='alert alert-danger'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Oups! vous ne pouvez pas accéder à cette page directement.</div>";

					redirectHome($Msgs);

				echo "</div>";

			}

		} elseif ($do == 'Edit') {

			// If this User exist, Delete
			if ( checkExistence('Client_ID', 'clients', (int)$_GET['Client_ID']) ) {

				$client = getClient((int)$_GET['Client_ID']);

?>

				<h1 class="text-center">Modifier le client</h1>

				<div class="container">

					<div class="col-md-2"></div>

					<div class="col-md-8">

						<div class="panel panel-primary item-infos">

							<div class="panel-heading">Informations du client</div>

							<div class="panel-body">

								<div class="row">

									<div class="col-md-12">

										<form class="form-horizontal" method="POST" action="?do=Update">

											<!-- Client Id Field -->
											<input type="hidden" name="Client_ID" value="<?php echo $client['Client_ID']; ?>">

											<!-- Start FullName Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="fullname">Nom complet</label>
												<div class="col-sm-10 col-md-6">
													<input  type 		= "text"
															name 		= "fullname"
															id 			= "fullname"
															class 		= "form-control"
															placeholder = "Nom complet"
															value 		= "<?php echo $client['Fullname']; ?>"
															required 	= "required"/>
												</div>
											</div>
											<!-- End FullName Field -->

											<!-- Start CIN Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="cin">CIN</label>
												<div class="col-sm-10 col-md-6">
													<input 	type 		= "text"
															name 		= "cin"
															id 			= "cin"
															class 		= "form-control"
															placeholder = "Carte d'identité nationale"
															value 		= "<?php echo $client['CIN']; ?>"
															required 	= "required"/>
												</div>
											</div>
											<!-- End CIN Field -->

											<!-- Start Email Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="phone">Téléphone</label>
												<div class="col-sm-10 col-md-6">
													<input  type 		= "number"
															min 		= "0"
															name 		= "phone"
															id 			= "phone"
															class 		= "form-control"
															placeholder = "Téléphone mobile"
															value 		= "<?php echo $client['Phone']; ?>"
															required 	= "required"/>
												</div>
											</div>
											<!-- End Email Field -->

											<!-- Start Address Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="address">Adresse</label>
												<div class="col-sm-10 col-md-6">
													<input  type 		= "text"
															name 		= "address"
															id 			= "address"
															class 		= "form-control"
															placeholder = "Adresse"
															value 		= "<?php echo $client['Address']; ?>"
															required 	= "required"/>
												</div>
											</div>
											<!-- End Address Field -->

											<!-- Start City / Postal Code Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="city">Ville</label>
												<div class="col-sm-10 col-md-3">
													<select name="city" id="city">
														<option value="0">. . .</option>
															<?php
															
																$cities = ['Agadir', 'Al Hoceïma',
																			'Béni Mellal',
																			'Casablanca',
																			'El Jadida', 'Errachidia',
																			'Fès',
																			'Kénitra', 'Khénifra', 'Khouribga',
																			'Larache',
																			'Marrakech', 'Martin', 'Mdiq', 'Meknès',
																			'Nador',
																			'Ouarzazate', 'Oujda',
																			'Rabat',
																			'Safi', 'Settat', 'Salé',
																			'Tanger', 'Taza', 'Tétouan'];

		    													foreach ($cities as $city) {

		    														$selected = $client['City'] == $city ? 'Selected="true"' : '';

																	echo '<option value="'. $city .'" '.$selected.'>'. $city .'</option>';
																
																}

															?>
													</select>
												</div>

												<div class="col-sm-10 col-md-3">
													<input  type 		= "number"
															min 		= "0"
															name 		= "zipcode"
															id 			= "zipcode"
															class 		= "form-control"
															placeholder = "Code postal"
															value 		= "<?php echo $client['Zip_Code']; ?>"
															required 	= "required"/>
												</div>
											</div>
											<!-- End City / Postal Code Field -->

											<!-- Start Submit Button Field -->
											<div class="form-group form-group-lg">
												<div class="col-sm-offset-4 col-sm-10">

													<input  type  = "submit"
															class = "btn btn-primary btn-md"
															value = "Valider"/>

													<input  type  = "reset"
															class = "btn btn-danger btn-md"
															value = "Réinitialiser"/>

													<a  href="<?php $urlCut = explode('=', $_SERVER['HTTP_REFERER']); $doValue = end($urlCut);
														if($doValue=='Update') { echo '?do=Manage'; } else { echo $_SERVER['HTTP_REFERER']; } ?>"
														class="btn btn-default btn-md">Annuler
													</a>
												
												</div>
											</div>
											<!-- End Submit Button Field -->
									
										</form>

									</div>

								</div>

							</div>

						</div>

					</div>

				</div>
<?php
			
			} else { // Error message : There is no such ID

				echo "<h1 class='text-center'>Erreur 404</h1>";

				echo "<div class='container'>";

					$Msgs[] = "<div class='alert alert-danger'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Oups! cette page n’existe pas...</div>";

					redirectHome($Msgs);

				echo "</div>";

			}

		} elseif ($do == 'Update') {

			if ($_SERVER['REQUEST_METHOD'] == 'POST'){

				echo "<h1 class='text-center'>Mettre à jour le client</h1>";

				echo "<div class='container'>";

					// Get variables from the Form
					$id 		= filter_var($_POST['Client_ID'], FILTER_SANITIZE_NUMBER_INT);
					$fullname 	= filter_var($_POST['fullname']	, FILTER_SANITIZE_STRING);
					$cin 		= filter_var($_POST['cin']		, FILTER_SANITIZE_STRING);
					$phone 		= filter_var($_POST['phone']	, FILTER_SANITIZE_NUMBER_INT);
					$address 	= filter_var($_POST['address']	, FILTER_SANITIZE_STRING);
					$city 		= filter_var($_POST['city']		, FILTER_SANITIZE_STRING);
					$zipcode 	= filter_var($_POST['zipcode']	, FILTER_SANITIZE_NUMBER_INT);

					// Validate the Form : conditions
					$formErrors = array();

					// Check if a Client (with this CIN) already exist in database
					if (checkExistenceUpdate("CIN", "clients", $cin, "Client_ID", $id)) {
						$formErrors[] = "Il y a déjà un compte avec <strong>le numéro de CIN entré</strong>.";
					}

					if (strlen($fullname) < 4) {
						$formErrors[] = "Le nom doit contenir <strong>au moins 4 caractères</strong>.";
					}

					if (empty($cin)) {
						$formErrors[] = "Le champ CIN est <strong>obligatoire</strong>";
					}

					if (strlen($phone) < 10) {
						$formErrors[] = "Le numéro de téléphone doit contenir <strong>au moins 10 chiffres</strong>.";
					}

					if (empty($address)) {
						$formErrors[] = "Le champ Adresse est <strong>obligatoire</strong>.";
					}

					if ($city == '0') {
						$formErrors[] = "Le champ Ville est <strong>obligatoire</strong>.";
					}

					if (empty($zipcode)) {
						$formErrors[] = "Le champ Code Postal est <strong>obligatoire</strong>.";
					}

					// Loop into Errors array
					if (!empty($formErrors)) {

						echo "<div class='alert alert-danger'>";

							foreach($formErrors as $error) {
								echo "<p><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> " . $error ."</p>";
							}

						echo "</div>";

						echo "<div class='alert alert-info'>";
							echo "<i class='fa fa-info-circle' aria-hidden='true'></i> ";
							echo "Retournez vers la page précédente pour compléter l’insertion du client.";
						echo "</div>";
					
					} else {

						// Update Client Informations_________________________________________________________________
						$updateClient = $con->prepare("UPDATE clients

													   SET 	  Fullname  = ?,
													   		  CIN 		= ?,
													   		  Address 	= ?,
													   		  City 		= ?,
													   		  Zip_Code 	= ?,
													   		  Phone 	= ?

													   WHERE  Client_ID = ?");

						$updateClient->execute(array($fullname,
													 $cin,
													 $address,
													 $city,
													 $zipcode,
													 $phone,
													 $id));

						// Success message____________________________________________________________________________
						$Msgs[] = '<div class="alert alert-success"><i class="fa fa-check-circle" aria-hidden="true"></i> ' . $updateClient->rowCount() . ' Enregistrement mis à jour!</div>';
						redirectHome($Msgs, 'back', 3);

					}

				echo "</div>";

			} else { // Error message : Direct browse_________________________________________________________________

				echo "<h1 class='text-center'>Erreur : Accès direct</h1>";

				echo "<div class='container'>";

					$Msgs[] = "<div class='alert alert-danger'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Oups! vous ne pouvez pas accéder à cette page directement.</div>";

					redirectHome($Msgs);

				echo "</div>";

			}
		
		} elseif ($do == 'Delete') {

			// Check if Get request UserID exist & is Numeric AND Get the integer Value of it
			$client_id = isset($_GET['Client_ID']) && is_numeric($_GET['Client_ID']) ? intval($_GET['Client_ID']) : 0;

			// If this User exist, Delete
			if ( checkExistence('Client_ID', 'clients', $client_id) ) {

				$deleteClient = $con->prepare("DELETE FROM clients WHERE Client_ID = ?");
				$deleteClient->execute(array($client_id));

				echo "<h1 class='text-center'>Suppression du client</h1>";

				echo "<div class='container'>";

				// Success message
				$Msgs[] = '<div class="alert alert-success"><i class="fa fa-check-circle" aria-hidden="true"></i> ' . $deleteClient->rowCount() . ' Enregistrement supprimé!</div>';
				redirectHome($Msgs, 'back', 3);

			} else { // Error message : There is no such ID

				echo "<h1 class='text-center'>Erreur 404</h1>";

				echo "<div class='container'>";

				$Msgs[] = "<div class='alert alert-danger'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Oups! cette page n’existe pas...</div>";

				redirectHome($Msgs);

				echo "</div>";

			}

			echo "</div>";

		} else { // Page Not Found !

			echo "<h1 class='text-center'>Erreur 404</h1>";

			echo "<div class='container'>";

				$Msgs[] = "<div class='alert alert-danger'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Oups! cette page n’existe pas...</div>";

				redirectHome($Msgs);

			echo "</div>";

		}
		
	}

	include_once $tpl . 'footer.php';
	
?>
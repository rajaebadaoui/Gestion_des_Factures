<?php 

	include_once "initialize.php";
	  
    if(isset($_POST['submit'])) { 

        if($_FILES['file']['tmp_name'] != "" && $_FILES['file']['type'] == "text/plain") {

            $file = $_FILES['file']['tmp_name'];

            $consommations = read_file($file);

            read_consommations($consommations);

        } else {

            $error = "Fichier invalide";

        }

        header("location:consumption.php");
    
    }
		
?>
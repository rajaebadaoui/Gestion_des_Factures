		
		<div class="footer_section">

			<div class="container">

				<footer class="text-center">

					<!--<p>ENSA Tétouan © <?php echo date("Y"); ?> - Génie Informatique 2</p>-->
					
				</footer>
				
			</div>

		</div>

		<script src="<?php echo $js.'fontawesome-all.js'; ?>"></script>

		<script src="<?php echo $js.'jquery-1.12.1.min.js'; ?>"></script>

		<script src="<?php echo $js.'jquery-ui.min.js'; ?>"></script>

		<script src="<?php echo $js.'bootstrap.min.js'; ?>"></script>

		<script src="<?php echo $js.'jquery.selectBoxIt.min.js'; ?>"></script>

		<script src="<?php echo $js.'backend.js'; ?>"></script>

		<script>

	  		function printdiv(printpage) {

				var headstr = "<html><head><title></title></head><body>";
				var footstr = "</body>";
				var newstr 	= document.all.item(printpage).innerHTML;
				var oldstr 	= document.body.innerHTML;

				document.body.innerHTML = headstr+newstr+footstr;
				window.print();
				document.body.innerHTML = oldstr;

				return false;
				
			};

  		</script>

	</body>

</html>
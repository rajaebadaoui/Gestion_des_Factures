<!DOCTYPE html>

<html>

	<head>

		<meta charset="UTF-8">
		
		<title><?php getTitle(); ?></title>

		<link rel="stylesheet" href="<?php echo $css.'jquery-ui.css'; ?>"/>

		<link rel="stylesheet" href="<?php echo $css.'jquery.selectBoxIt.css'; ?>"/>

		<link rel="stylesheet" href="<?php echo $css.'bootstrap.css'; ?>"/>

		<link rel="stylesheet" href="<?php echo $css.'style.css'; ?>"/>

	</head>

	<body style='background-image: url("layout/css/images/background.jpg");'>
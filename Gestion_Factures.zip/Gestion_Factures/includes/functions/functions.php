<?php
	// Title Function (Dynamic Title) (v1.0)_________________________________________________
	//_______________________________________________________________________________________
	function getTitle() {

		global $pageTitle;

		if (isset($pageTitle)) {
		
			echo $pageTitle;
		
		} else {
		
			echo 'Gestion des Factures';
		
		}
	}

	// Redirect Function ($Msg, $url, $seconds) (v2.0)____________________________________________
	// * $Msg		: Message [Ex: Error, Success, warning]
	// * $url 		: Nouvelle direction
	// * $seconds 	: Temps de redirection
	//____________________________________________________________________________________________
	function redirectHome($Msgs, $url=null, $seconds=5) {

		if($url == null){

			$url  = 'index.php';
			$link = 'la page d\'Accueil';

		} elseif ($url == 'clients') { // Back End

			$url  = 'clients.php?do=Manage';
			$link = 'la page de Gestion des Clients';

		} else {

			// $url = 'back to previous page';

			if(isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER'])) {

				$url = $_SERVER['HTTP_REFERER'];
				$link = 'la page précédente';

			} else {

				$url = 'index.php';
				$link = 'la page d\'Accueil';

			}
			
		}

		// Loop into Msgs array
		foreach($Msgs as $msg) {
			echo $msg;
		}

		//echo $Msg;
		echo "<div class='alert alert-info'><i class='fa fa-info-circle' aria-hidden='true'></i> Vous serez redirigé vers $link après $seconds secondes.</div>";

		header("refresh:$seconds;url=$url");

	}


	// Check Client Function (v1.0)__________________________________________________________
	// * $select 	: The column to select [Ex: CIN]
	// * $from 		: The table to select from [Ex: clients]
	// * $value 	: The value of select [Ex: CIN]
	//_______________________________________________________________________________________
	function checkExistence($select, $from, $value) {

		global $con;

		$statement = $con->prepare("SELECT $select FROM $from WHERE $select = ?");
		$statement->execute(array($value));
		$count = $statement->rowCount();

		if ($count > 0) {

			return 1;

		} else {

			return 0;

		}

	}

	// Check Client (Update) Function (v1.0)________________________________________________________
	// * $select 	: The column to select [Ex: CIN]
	// * $from 		: The table to select from [Ex: clients]
	// * $value 	: The value of select [Ex: CIN]
	// * $id 		: Id item [Ex: Client_ID]
	// * $idvalue 	: The value of the ID
	//______________________________________________________________________________________________
	function checkExistenceUpdate($select, $from, $value, $id, $idvalue) {

		global $con;

		$statement = $con->prepare("SELECT 	$select
									FROM 	$from
									WHERE 	$select  = ?
									AND 	$id 	!= ?");

		$statement->execute(array($value,$idvalue));

		$count = $statement->rowCount();

		if ($count > 0) {

			return 1;

		} else {

			return 0;

		}

	}


	// Title Function (Dynamic Title) (v1.0)_________________________________________________
	//_______________________________________________________________________________________
	function isAdmin($Emp_ID) {

		global $con;

		$period = date('m') - 1;

		$isAdmin = $con->prepare("SELECT * FROM employees
								  WHERE Emp_ID 	 = $Emp_ID
								  AND 	Is_Admin = 1");

		$isAdmin->execute();

		$response = $isAdmin->rowCount();

		if ($response != 0) {

			return 1;

		} else {

			return 0;

		}

	}

	// Get Employees Function (v1.0)_________________________________________________________	//_______________________________________________________________________________________
	function getEmployees($sortBy='Emp_ID', $sortWay='DESC') {

		global $con;

		$getEmployees = $con->prepare("SELECT * FROM employees
									   WHERE Emp_ID != 1
									   ORDER BY $sortBy $sortWay");

		$getEmployees->execute();

		$employees = $getEmployees->fetchAll();

		return $employees;

	}

	// Get Employee Function (v1.0)__________________________________________________________
	//_______________________________________________________________________________________
	function getEmployee($emp_ID) {

		$emp_ID = (int) $emp_ID;

		global $con;

		$getEmployee = $con->prepare("SELECT * FROM employees
									  WHERE Emp_ID = $emp_ID
									  LIMIT 1");

		$getEmployee->execute();

		$employee = $getEmployee->fetch();

		return $employee;

	}

	// Get Clients Function (v1.0)___________________________________________________________	//_______________________________________________________________________________________
	function getClients($sortBy='Client_ID', $sortWay='DESC') {

		global $con;

		$getClients = $con->prepare("SELECT * FROM clients

									 INNER JOIN employees
									 ON clients.Emp_ID = employees.Emp_ID

									 ORDER BY $sortBy $sortWay");

		$getClients->execute();

		$clients = $getClients->fetchAll();

		return $clients;

	}

	// Get Client Function (v1.0)____________________________________________________________
	//_______________________________________________________________________________________
	function getClient($client_ID) {

		$client_ID = (int) $client_ID;

		global $con;

		$getClient = $con->prepare("SELECT * FROM clients
									WHERE Client_ID = $client_ID
									LIMIT 1");

		$getClient->execute();

		$client = $getClient->fetch();

		return $client;

	}


	// Get HT Function (v1.0)________________________________________________________________
	//_______________________________________________________________________________________
	function getT1HT($consommation) {

		return $consommation * 0.91;

	}

	function getT2HT($consommation) {

		return $consommation * 1.01;

	}

	function getT3HT($consommation) {

		return $consommation * 1.12;

	}

	function getHT($consommation) {

		if ($consommation <= 100) {

			return $consommation * 0.91;

		} elseif ($consommation <= 200) {

			return 100 * 0.91 + ($consommation - 100) * 1.01;

		} else {

			return 100 * 0.91 + 100 * 1.01 + ($consommation - 200) * 1.12;

		}

	}

	// Get TTC Function (v1.0)________________________________________________________________
	//________________________________________________________________________________________
	function getTTC($ht) {

		return 1.14 * $ht;

	}

	function getTax($ht) {

		return 0.14 * $ht;

	}

	// Generate Code Function (v1.0)
	// * $length 	: Length of the code
	// * $start_pos	: Refers to the position of the string to start cutting
	// * $repeat_no	: Number of times the input string should be repeated
	//________________________________________________________________________________________
	function generateCode($length = 10, $start_pos = 50, $repeat_no = 100) {

		$possibleChars 	= '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';

		$string_name	= str_shuffle(str_repeat($possibleChars, $repeat_no));

		return substr($string_name, $start_pos, $length);

	}

	// Get Invoices Function (v1.0)___________________________________________________________
	//________________________________________________________________________________________
	function getInvoices($sortBy='Period', $sortWay='DESC') {

		global $con;

		$getInvoices = $con->prepare("SELECT * FROM invoices

									  INNER JOIN clients
									  ON invoices.Client_ID = clients.Client_ID

									  INNER JOIN employees
									  ON invoices.Emp_ID = employees.Emp_ID

									  WHERE invoices.Archive = 0

									  ORDER BY $sortBy $sortWay");

		$getInvoices->execute();

		return $getInvoices->fetchAll();

	}

	// Get Invoice Function (v1.0)____________________________________________________________
	//________________________________________________________________________________________
	function getInvoice($Invoice_ID) {

		global $con;

		$getInvoice = $con->prepare("SELECT * FROM invoices

									 INNER JOIN clients
									 ON invoices.Client_ID = clients.Client_ID

									 INNER JOIN employees
									 ON invoices.Emp_ID = employees.Emp_ID

									 WHERE Invoice_ID = $Invoice_ID");

		$getInvoice->execute();

		return $getInvoice->fetch();

	}

	// Insert Consumption Function (v1.0)_____________________________________________________
	//________________________________________________________________________________________
	function createInvoice($Client_ID, $counter) {

		global $con;

		$reference 	= generateCode();
		$kwh 		= calculateConsumption($Client_ID, $counter);
		$ht 		= getHT($kwh);
		$limit_date = date("Y-m-t", strtotime('now'));

		$insertInvoice = $con->prepare("INSERT INTO invoices (Reference,
															  Client_ID,
															  Period,
															  Counter,
															  KWH,
															  HT,
															  Limit_Date,
															  Emp_ID,
															  Printed,
															  Status,
															  Archive)
										VALUES (:Reference,
												:Client_ID,
												:Period,
												:Counter,
												:KWH,
												:HT,
												:Limit_Date,
												:Emp_ID,
												0,0,0)");

		$insertInvoice->execute(array(':Reference' 	=> $reference,
									  ':Client_ID'	=> $Client_ID,
									  ':Period' 	=> period(),
									  ':Counter'	=> $counter,
									  ':KWH' 		=> $kwh,
									  ':HT' 		=> $ht,
									  ':Limit_Date' => $limit_date,
									  ':Emp_ID' 	=> $_SESSION['Emp_ID']));

	}


	// Update Consumption Function (v1.0)_____________________________________________________
	//________________________________________________________________________________________
	function updateInvoice($Client_ID, $counter) {

		global $con;

		$kwh 	= calculateConsumption($Client_ID, $counter);
		$ht 	= getHT($kwh);

		$insertInvoice = $con->prepare("UPDATE invoices 
										SET    Counter = ?,
											   KWH 	  = ?,
											   HT 	  = ?
										WHERE  Client_ID = ?
										AND    Period = ?");

		$insertInvoice->execute(array($counter, $kwh, $ht, $Client_ID, period()));

	}


	// Input, Add, Update, Consult Visibility Function (v1.0)________________________________________
	//________________________________________________________________________________________
	function inputVisibility($Client_ID) {

		global $con;

		$isCreatedUpdate = $con->prepare("SELECT * FROM invoices
										  WHERE Client_ID = :client_id
										  AND   Period    = :period");

		$isCreatedUpdate->execute(array('client_id' => $Client_ID, ':period' => period()));

		$nbrRows = $isCreatedUpdate->rowCount();

		if ($nbrRows != 0) {

			$invoiceInfos = $isCreatedUpdate->fetch();

			if ($invoiceInfos['Printed']) {

				return 'disabled="true"';

			}

		}

	}

	function addVisibility($Client_ID) {

		global $con;

		$isCreated = $con->prepare("SELECT * FROM invoices
									WHERE Client_ID = :client_id
									AND   Period 	= :period");

		$isCreated->execute(array('client_id' => $Client_ID, ':period' => period()));

		$response = $isCreated->rowCount();

		if ($response != 0) {

			return 'disabled="true"';

		}

	}

	function updateVisibility($Client_ID) {

		global $con;

		$isCreatedUpdate = $con->prepare("SELECT * FROM invoices
										  WHERE Client_ID = :client_id
										  AND   Period    = :period");

		$isCreatedUpdate->execute(array('client_id' => $Client_ID, ':period' => period()));

		$nbrRows = $isCreatedUpdate->rowCount();

		if ($nbrRows == 0) {

			return 'disabled="true"';

		}

	}

	function consultVisibility($Client_ID) {

		global $con;

		$isCreated = $con->prepare("SELECT * FROM invoices
									WHERE Client_ID = :client_id
									AND   Period 	= :period");

		$isCreated->execute(array('client_id' => $Client_ID, ':period' => period()));

		$response = $isCreated->rowCount();

		if ($response == 0) {

			return 'disabled="true"';

		}

	}

	function getLastInvoiceID($Client_ID) {

		global $con;

		$getConsumption = $con->prepare("SELECT Invoice_ID
										 FROM 	invoices
										 WHERE 	Client_ID = :client_id
										 AND 	Period 	  = :period");

		$getConsumption->execute(array('client_id' => $Client_ID, ':period' => period()));

		$res = $getConsumption->fetch();

		return $res['Invoice_ID'];

	}

	function getCounter($Client_ID) {

		global $con;

		$getCounter = $con->prepare("SELECT Counter
										 FROM 	invoices
										 WHERE 	Client_ID = :client_id
										 AND 	Period 	  = :period");

		$getCounter->execute(array('client_id' => $Client_ID, ':period' => period()));

		$res = $getCounter->fetch();

		return $res['Counter'];

	}

	// isExist Function (v1.0)________________________________________________________________
	// Check if the invoice of the period m-1 exist
	//________________________________________________________________________________________
	function isExist($Client_ID) {

		global $con;

		$isCreated = $con->prepare("SELECT * FROM invoices
									WHERE Client_ID = :client_id
									AND   Period 	= :period");

		$isCreated->execute(array('client_id' => $Client_ID, ':period' => period()));

		$response = $isCreated->rowCount();

		if ($response != 0) {

			return 1;

		} else {

			return 0;

		}

	}

	function period() {

		$period = date('Y-m-d', strtotime('now'));
		$period = strtotime ('-1 month', strtotime($period));
		$period = date('Y-m-01', $period);

		return $period;

	}

	function previousPeriod() {

		$period = date('Y-m-d', strtotime('now'));
		$period = strtotime ('-2 month', strtotime($period));
		$period = date('Y-m-01', $period);

		return $period;

	}

	function calculateConsumption($Client_ID, $current) {

		global $con;

		$calculateConsumption = $con->prepare('	SELECT * FROM invoices 
												WHERE Client_ID = :client_id
												AND Period = :period');

		$calculateConsumption->execute(array('client_id' => $Client_ID, ':period' => previousPeriod()));

		$res = $calculateConsumption->fetch();

		if (!empty($res['Counter'])) {

			$previous = $res['Counter'];

		} else {

			$previous = 0;

		}

		$consumption = $current - $previous;

		return $consumption;

	}


	function read_file($file) {
        // Ouverture du fichier
        $file_open = fopen($file, 'r');

        // Lecture du fichier
        $file_read = fread($file_open, filesize($file));

        // Fermeture du fichier
        fclose($file_open);

        $consos = explode("\r\n", $file_read);

        return $consos;
      

    }

    function read_consommations($consommations) {

    	global $con;

    	foreach ($consommations as $consommation) {

    		list($Emp_ID, $Client_ID, $counter, $date) = explode("|", $consommation);

    		$reference 	= generateCode();
    		$kwh 		= calculateConsumption($Client_ID, $counter);
			$ht 		= getHT($kwh);

			// Period____________________________________________________
			$period = date('Y-m-d', strtotime($date));
			$period = strtotime ('-1 month', strtotime($period));
			$period = date('Y-m-01', $period);

			// Limit_date________________________________________________
			$limit_date = date('Y-m-t', strtotime($date));

			$insertInvoice = $con->prepare("INSERT INTO invoices (Reference,
															  Client_ID,
															  Period,
															  Counter,
															  KWH,
															  HT,
															  Limit_Date,
															  Emp_ID,
															  Printed,
															  Status,
															  Archive)
											VALUES (:Reference,
													:Client_ID,
													:Period,
													:Counter,
													:KWH,
													:HT,
													:Limit_Date,
													:Emp_ID,
													0,0,0)");

			$insertInvoice->execute(array(':Reference' 	=> $reference,
										  ':Client_ID'	=> $Client_ID,
										  ':Period' 	=> $period,
										  ':Counter'	=> $counter,
										  ':KWH' 		=> $kwh,
										  ':HT' 		=> $ht,
										  ':Limit_Date' => $limit_date,
										  ':Emp_ID' 	=> $Emp_ID));
			
    	}

    }

?>
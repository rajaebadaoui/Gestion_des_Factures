$(function() {

	// Turn On the SelectBoxIt
	$("select").selectBoxIt({
	
		autoWidth: false
		
	});

	// Boutton Supprimer : Message de confirmation
	$('.confirm').click(function() {

		return confirm("Cette action va supprimer l'élément sélectionné! continuer quand même ?");

	});

});
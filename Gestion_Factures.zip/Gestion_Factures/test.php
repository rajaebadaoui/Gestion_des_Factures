<?php
	
	include_once 'initialize.php';
	include "connect.php";
	
	function read_file($file) {
        // Ouverture du fichier
        $file_open = fopen($file, 'r');

        // Lecture du fichier
        $file_read = fread($file_open, filesize($file));

        // Fermeture du fichier
        fclose($file_open);

        $consos = explode("\r\n", $file_read);

        return $consos;

        

    }
    function read_consos($consos) {

    	foreach ($consos as $conso) {
    		list($id_agent, $id_client, $consommation, $date) = explode("|", $conso);

    		var_dump($id_agent, $id_client, $consommation, $date);

			$insertClient = $con->prepare("INSERT INTO invoices(Consommation,
																   Limit_Date)
														VALUES(:Consommation,
															   :Limit_Date)
															   Where 
															   :Client_ID" );
						
						$insertClient->execute(array('Consommation' => $consommation,
													 'Limit_Date'	=> $date,
													 'Client_ID'	=> $id_client,
													 'Emp_ID' 	=> $_SESSION['Emp_ID']));
			
    	}

    }

    // Hadou ghi bach kanchouf chnou wa93 fost la fonction
    //var_dump(read_file("test.txt"));

	//read_consos(read_file("test.txt"));
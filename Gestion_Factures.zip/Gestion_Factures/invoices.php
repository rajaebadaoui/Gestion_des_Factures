<?php

	/*==================================
	=> Gestion des factures : Afficher
	===================================*/

	session_start();

	$pageTitle = 'Gestion des factures';

	include_once 'initialize.php';

	if (!isset($_SESSION['Login'])) {

		header('Location: login.php');
		exit();

	} else {

		$do = isset($_GET['do']) ? $_GET['do'] : '';

		if ($do == '' || !isset($_GET['do'])) {

			// Get Invoices
			$invoices = getInvoices();

?>

			<div class="container text-center title dashboard">
				
				<div class="row">

					<h1 class="text-center">Gestion des Factures</h1>

					<div class="table-responsive">

						<table class="main-table table table-bordered manage-members text-center">

							<tr>
								<td>#</td>
								<!--<td>Référence</td>-->
								<td>Nom complet</td>
								<td>CIN</td>
								<td>Période</td>
								<td>Date limite</td>								
								<td>Statut</td>
								<td>Créé par</td>
								<td>Contrôle</td>
							</tr>

							<?php
								foreach ($invoices as $invoice) {

									echo '<tr>';

										echo '<td class="text-center">' . $invoice['Invoice_ID'] . '</td>';
										//echo '<td class="text-center">' . $invoice['Reference']  . '</td>';
										echo '<td class="text-center">' . $invoice['Fullname'] 	 . '</td>';
										echo '<td class="text-center">' . $invoice['CIN']	 	 . '</td>';
										echo '<td class="text-center">' . $invoice['Period'] 	 . '</td>';
										echo '<td class="text-center">' . $invoice['Limit_Date'] . '</td>';
										
										echo '<td class="text-center">';

											if($invoice['Status']){

												echo '<span class="label label-success"><i class="fa fa-check-circle fa-fw"></i> Payée</span>';

											} else {

												echo '<span class="label label-warning"><i class="fa fa-spinner fa-spin fa-fw"></i> En attente de paiement</span>';

											}

										echo '</td>';

										echo '<td class="text-center">' . $invoice['Emp_Name'] . '</td>';

										echo '<td class="text-center">';
											echo '<a href="invoice.php?invoiceid='.$invoice['Invoice_ID'].'" class="btn btn-success"><i class="fa fa-print"></i> Consulter</a>';
											echo '<a href="archive.php?invoiceid='.$invoice['Invoice_ID'].'" class="btn btn-danger"><i class="fa fa-print"></i> Archiver</a>';
										echo '</td>';

									echo '</tr>';

								}
							?>

						</table>

					</div>

					<!-- Add New Client Button -->
					<div class="text-left">
						<a href="index.php" class="btn btn-warning"><i class="fas fa-undo"></i> Retour</a>
					</div>

				</div>

			</div>

<?php
		}
		
	}

	include_once $tpl . 'footer.php';
	
?>
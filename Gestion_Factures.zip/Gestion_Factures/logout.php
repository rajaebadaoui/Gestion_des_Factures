<?php
	
	session_start(); 				// Start the session

	$pageTitle = 'Se déconnecter';

	include_once 'initialize.php';

	session_unset(); 				// Unset the data of the session

	session_destroy(); 				// Destroy the session

	header('Location: login.php'); 	// Go to the Index page

	exit();

?>
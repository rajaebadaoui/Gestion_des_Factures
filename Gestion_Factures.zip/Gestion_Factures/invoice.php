<?php

	session_start();

	// Check if user is logged in
	if (!isset($_SESSION['Login'])) {

		header('Location: index.php'); // Redirect to Index Page
		exit();

	} else {

		// Check if Get request Invoice ID exist & is Numeric AND Get the integer Value of it
		$invoiceID = isset($_GET['invoiceid']) && is_numeric($_GET['invoiceid']) ? intval($_GET['invoiceid']) : 0;

		// Page Title
		$pageTitle = 'Facture N°'.$invoiceID;

		include_once 'initialize.php';

		// Get Invoice Informations
		$invoiceInfos = getInvoice($invoiceID);

		if (empty($invoiceInfos)) {

			header('Location: index.php'); // Redirect to the Homepage

		} else {

?>

			<div id="main-container" class="container" id="div_print">
				
				<!-- Main Heading Starts -->
				<h1 class="main-heading invoice-title"><?php echo 'Facture N°'.$invoiceID; ?></h1>
				<!-- Main Heading Ends -->

				<!-- Starts -->
				<div class="row invoice" id="div_print">
					<!-- Invoice Form Starts -->
					<div class="container">
						<div class="row color-invoice">
							<div class="col-md-12">

								<span class="pull-right" style="font-size: 20px;">
									<?php
										echo '<p>Facture N°'.$invoiceID.'<br>';
										//echo 'Référence : '.$invoiceInfos['Reference'].'<br>';
										echo 'Période : '.$invoiceInfos['Period'].'</p>';
									?>
								</span>

								<div class="row">
									<div class="col-lg-7 col-md-7 col-sm-7 pull-left">

										<img src="<?php echo $css.'images/'; ?>veolia.png" class="logo">

										<ul class="list-unstyled contact-details">
											<li class="clearfix">
												<i class="fa fa-map-marker fa-fw pull-left"></i>
												<span class="pull-left">AV CASABLANCA, 93000 - TETOUAN</span>
											</li>
											<li class="clearfix">
												<i class="fa fa-phone fa-fw pull-left" aria-hidden="true"></i>
												<span class="pull-left">08020 08000</span>
											</li>
										</ul>
									</div>
								</div><hr>

				        		<div class="row">
				         			<div class="col-lg-5 col-md-5 col-sm-5">

				            			<img src="<?php echo $css.'images/'; ?>code.png" class="code">

				            			<h4><?php echo 'M. '.$invoiceInfos['Fullname']; ?></h4>

				            			<ul class="list-unstyled contact-details">
											<li class="clearfix"> 
												<span class="pull-left"><?php echo $invoiceInfos['Address'].', '.$invoiceInfos['Zip_Code'].' - '.$invoiceInfos['City']; ?></span>
											</li>
											<li class="clearfix">
												<span class="pull-left"><?php echo '+212 '.$invoiceInfos['Phone']; ?></span>
											</li>
										</ul>

				          			</div>

				          			<div class="col-lg-7 col-md-7 col-sm-7">
										<div class="panel panel-default">
					                        <div class="panel-heading">
					                            Evolution de votre consommation
					                        </div>
					                        <!-- /.panel-heading -->
					                        <div class="panel-body">
					                            
					                        	<?php

					                        		$Client_ID = $invoiceInfos['Client_ID'];

					                        		include 'chart.php';
					                        	?>

											</div>
											<!-- /.panel-body -->
										</div>
									</div>
				        		</div><hr>

				        		<div class="row">
				        			<div class="col-lg-6 col-md-6 col-sm-6">
				            			<strong>Usage :</strong>
				        			</div>
				        		</div><br>

				        		<div class="row">
				          			<div class="col-lg-12 col-md-12 col-sm-12">
				            			<div class="table-responsive">
				             				<table class="table table-striped table-bordered">
					                			<thead>
					                				<tr>
														<th>Tranches</th>
														<th>Consommation (KWH)</th>
														<th>Montant HT (MAD)</th>
														<th>Taxes (MAD)</th>
														<th>Sous-total (MAD)</th>
					                  				</tr>
					                			</thead>

					                			<tbody>
					                				<?php

					                					if ($invoiceInfos['KWH'] <= 100) {

					                						echo '<tr>';
																echo '<td>Tranche 1</td>';
																echo '<td>'.$invoiceInfos['KWH'].'</td>';
																echo '<td>'.$invoiceInfos['HT'].'</td>';
																echo '<td>'.getTax($invoiceInfos['HT']).'</td>';
																echo '<td>'.getTTC($invoiceInfos['HT']).'</td>';
															echo '</tr>';

															$totalHT 	= $invoiceInfos['HT'];
															$totalTax 	= getTax($invoiceInfos['HT']);
															$total 		= getTTC($invoiceInfos['HT']);

					                					} elseif ($invoiceInfos['KWH'] <= 200) {

					                						echo '<tr>';
																echo '<td>Tranche 1</td>';
																echo '<td>100</td>';
																echo '<td>'.getT1HT(100).'</td>';
																echo '<td>'.getTax(getT1HT(100)).'</td>';
																echo '<td>'.getTTC(getT1HT(100)).'</td>';
															echo '</tr>';

															echo '<tr>';
																echo '<td>Tranche 2</td>';
																echo '<td>'.($invoiceInfos['KWH']-100).'</td>';
																echo '<td>'.getT2HT($invoiceInfos['KWH']-100).'</td>';
																echo '<td>'.getTax(getT2HT($invoiceInfos['KWH']-100)).'</td>';
																echo '<td>'.getTTC(getT2HT($invoiceInfos['KWH']-100)).'</td>';
															echo '</tr>';

															$totalHT 	= getT1HT(100) + getT2HT(100);
															$totalTax 	= getTax(getT1HT(100)) + getTax(getT2HT($invoiceInfos['KWH']-100));
															$total 		= getTTC(getT1HT(100)) + getTTC(getT2HT($invoiceInfos['KWH']-100));

					                					} else {

					                						echo '<tr>';
																echo '<td>Tranche 1</td>';
																echo '<td>100</td>';
																echo '<td>'.getT1HT(100).'</td>';
																echo '<td>'.getTax(getT1HT(100)).'</td>';
																echo '<td>'.getTTC(getT1HT(100)).'</td>';
															echo '</tr>';

															echo '<tr>';
																echo '<td>Tranche 2</td>';
																echo '<td>100</td>';
																echo '<td>'.getT2HT(100).'</td>';
																echo '<td>'.getTax(getT2HT(100)).'</td>';
																echo '<td>'.getTTC(getT2HT(100)).'</td>';
															echo '</tr>';

															echo '<tr>';
																echo '<td>Tranche 3</td>';
																echo '<td>'.($invoiceInfos['KWH']-200).'</td>';
																echo '<td>'.getT3HT($invoiceInfos['KWH']-200).'</td>';
																echo '<td>'.getTax(getT3HT($invoiceInfos['KWH']-200)).'</td>';
																echo '<td>'.getTTC(getT3HT($invoiceInfos['KWH']-200)).'</td>';
															echo '</tr>';

															$totalHT 	= getT1HT(100) + getT2HT(100) + getT3HT($invoiceInfos['KWH']-200);
															$totalTax 	= getTax(getT1HT(100)) + getTax(getT2HT(100)) + getTax(getT3HT($invoiceInfos['KWH']-200));
															$total 		= getTTC(getT1HT(100)) + getTTC(getT2HT(100)) + getTTC(getT3HT($invoiceInfos['KWH']-200));

					                					}
					                					
					                				?>
					                			</tbody>

								                <tfoot>
													<tr>
														<td colspan="2">Total</td>
														<?php

															echo '<td>'.$totalHT.'</td>';
															echo '<td>'.$totalTax.'</td>';
															echo '<td>'.$total.'</td>';

														?>
													</tr>
												</tfoot>
											</table>
										</div><hr>

										

										<div>
											<h4>
												<strong><?php echo 'Total : '.getTTC($invoiceInfos['HT']).' MAD'; ?></strong>
											</h4>
										</div><hr>

									</div>
				        		</div>

								<div class="row">
									<div class="col-lg-12 col-md-12 col-sm-12">
										<a href="" class="btn btn-default btn-sm" onclick="printdiv('div_print');"><i class="fa fa-print" aria-hidden="true"></i> Print</a>
										<a href="<?php echo $_SERVER['HTTP_REFERER']; ?>" class="btn btn-default btn-sm">Back</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Invoice Form Ends -->
				</div>
				<!-- Ends -->
			</div>

<?php
		
		}
	}

	include $tpl . 'footer.php';

?>
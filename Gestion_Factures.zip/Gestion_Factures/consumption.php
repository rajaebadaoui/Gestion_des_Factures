<?php

	/*=============================================================
	=> Insertion des Consommations : Ajouter | Modifier | Supprimer
	==============================================================*/

	session_start();

	$pageTitle = 'Insertion des Consommations';

	include_once 'initialize.php';

	if (!isset($_SESSION['Login'])) {

		header('Location: login.php');
		exit();

	} else {

		$do = isset($_GET['do']) ? $_GET['do'] : '';

		if ($do == '' || !isset($_GET['do'])) {

			// Get Clients
			$clients = getClients();

?>

			<div class="container text-center title dashboard">
				
				<div class="row">

					<h1 class="text-center">Insertion des Consommations</h1>

					<div class="table-responsive">

						<table class="main-table table table-bordered manage-members text-center">

							<tr>
								<td>#</td>
								<td>Nom complet</td>
								<td>Adresse</td>
								<td>Ville</td>
								<td>Code postal</td>
								<td>Compteur (KWH)</td>
								<td>Contrôle</td>
							</tr>

							<?php

								foreach ($clients as $client) {

									echo '<tr>';

										echo '<form method="POST" action="consumption.php?do=wInvoice">';

											echo '<td class="text-center">' . $client['Client_ID'] 	. '</td>';
											echo '<td class="text-center">' . $client['Fullname'] 	. '</td>';
											echo '<td class="text-center">' . $client['Address'] 	. '</td>';
											echo '<td class="text-center">' . $client['City'] 		. '</td>';
											echo '<td class="text-center">' . $client['Zip_Code'] 	. '</td>';

											echo '<td class="text-center">';

												echo '<div class="col-md-12">';

													echo '<div class="row">';

														// Client ID_______________________________________________________________________________________________
														echo '<input type="hidden" name="Client_ID" value="'.$client['Client_ID'].'">';

														// Consommation____________________________________________________________________________________________
														$placeholder = isExist($client['Client_ID']) ? getCounter($client['Client_ID']).' KWH' : '';

														echo '<input type="number" name="consumption" min="0" class="form-control input-sm" placeholder="'.$placeholder.'" required="true" '.inputVisibility($client['Client_ID']).'>';

													echo '</div>';

												echo '</div>';

											echo '</td>';

											echo '<td class="text-center">';

												echo '<div class="col-md-12">';

													echo '<div class="row">';

														echo '<button type="submit" name="Add" class="btn btn-success" '.addVisibility($client['Client_ID']).'>';
															echo '<i class="fa fa-plus" aria-hidden="true"></i> Ajouter';
														echo '</button>';

														echo '<button type="submit" name="Update" class="btn btn-primary" '.updateVisibility($client['Client_ID']).inputVisibility($client['Client_ID']).'>';
															echo '<i class="fa fa-edit" aria-hidden="true"></i> Mettre à jour';
														echo '</button>';

														$url = isExist($client['Client_ID']) ? 'invoice.php?invoiceid='.getLastInvoiceID($client['Client_ID']) : 'consumption.php#';

														echo '<a href="'.$url.'" class="btn btn-warning" '.consultVisibility($client['Client_ID']).'>';
															echo '<i class="fa fa-file-alt" aria-hidden="true"></i> Facture';
														echo '</a>';

													echo '</div>';

												echo '</div>';

											echo '</td>';

										echo '</form>';

									echo '</tr>';

								}
								
							?>

						</table>

					</div>
					
					<!-- Insertion par Fichier -->
					<table>
						<tr>
							<td>
								<div class="text-left">
									<a href="index.php" class="btn btn-warning"><i class="fas fa-undo"></i> Retour</a>
								</div>
							</td>
							<td>
								<form enctype="multipart/form-data" action="insertion.php" method="POST">
									<div class="text-right">
										<label class="custom-file">
											<input type="file" name="file" id="file" class="custom-file-input">
											<span class="custom-file-control"></span>
										</label>
										<input type="submit" name="submit" id="submit" class="btn btn-primary" value="Valider">
									</div>
								</form>	
							</td>
						</tr>
					</table>
					
				</div>

			</div>

<?php

		} elseif ($do = 'wInvoice') {

			if ($_SERVER['REQUEST_METHOD'] == 'POST') {

				if (isset($_POST['Add'])) {

					if (isset($_POST['consumption']) && !isExist((int)$_POST['Client_ID'])) {

						$Client_ID 		= $_POST['Client_ID'];
						$consumption 	= $_POST['consumption'];

						createInvoice($Client_ID, $consumption);
						header('Location: consumption.php');

					} else {

						header('Location: consumption.php');

					}

				} elseif (isset($_POST['Update'])) {

					if (!empty($_POST['consumption']) && isExist($_POST['Client_ID'])) {

						$Client_ID 		= $_POST['Client_ID'];
						$consumption 	= $_POST['consumption'];

						updateInvoice($Client_ID, $consumption);
						header('Location: consumption.php');

					} else {

						header('Location: consumption.php');

					}

				} else {

					header('Location: consumption.php');

				}

			} else {

				header('Location: index.php');

			}

		}
		
	}

	include_once $tpl . 'footer.php';
	
?>
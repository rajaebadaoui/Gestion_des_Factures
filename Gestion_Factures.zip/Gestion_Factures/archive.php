<?php

	session_start();

	require_once 'connect.php';

	$invoice_id = $_GET['invoiceid'];

	$archive = $con->prepare('UPDATE invoices SET Archive = 1 WHERE Invoice_ID = :invoice_id');

	$archive->execute(array(':invoice_id' => $invoice_id));

	header('Location: invoices.php');

?>
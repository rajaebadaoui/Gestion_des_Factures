<?php // Initialize File
	
	// Connect to the Database__________________________________________________________________
	require_once 'connect.php';

	// Routes___________________________________________________________________________________
	$func 		= 'includes/functions/';			// Functions Directory
	$tpl 		= 'includes/templates/';			// Templates Directory
	$css 		= 'layout/css/';					// CSS Directory
	$css_img	= 'layout/css/images/';				// CSS Directory
	$js 		= 'layout/js/';						// JavaScript Directory

	// Include functions file___________________________________________________________________
	include_once $func . 'functions.php';

	// Include header file______________________________________________________________________
	include_once $tpl . 'header.php';

	// Include navbar file______________________________________________________________________
	include_once $tpl . 'navbar.php';

?>
<?php

	ob_start();

	session_start();

	$pageTitle 	= 'Se connecter';

	include 'initialize.php';

	if (isset($_SESSION['Login'])){

		header('Location: index.php'); // Redirect to the Dashboard Page

	}

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {

		$username 	= filter_var($_POST['login'], FILTER_SANITIZE_STRING);
		$password 	= filter_var($_POST['pass'], FILTER_SANITIZE_STRING);
		$hashedPass = sha1($password);

		// Check if the User exist in the Database
		$stmt = $con->prepare("SELECT *
										FROM
											employees
										WHERE
											Login = ?
										AND
											Password = ?
										LIMIT 1");

		$stmt->execute(array($username, $hashedPass));
		$row 	= $stmt->fetch();
		$count 	= $stmt->rowCount();

		if($count > 0) {

			$_SESSION['Emp_ID'] 	= $row['Emp_ID']; 		// Register Session ID
			$_SESSION['FullName'] 	= $row['FullName']; 	// Register Full Name
			$_SESSION['Login'] 		= $row['Login'];		// Register Session Name
			$_SESSION['Role'] 		= $row['Is_Admin'];		// Register Session Role
	
			header('Location: index.php'); 					// Redirect to Dashboard Page
			exit();

		}

	}

?>
	<div class="container">

		<form class="login" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">

			<h2 class="text-center">Tableau de bord</h2>

			<div class="input-group margin-bottom-sm">
				<span class="input-group-addon"><i class="fa fa-user fa-fw" aria-hidden="true"></i></span>
				<input class="form-control" type="text" name="login" placeholder="Nom d'utilisateur" autocomplete="off"/>
			</div>

			<div class="input-group">
				<span class="input-group-addon"><i class="fa fa-key fa-fw" aria-hidden="true"></i></span>
				<input class="form-control" type="password" name="pass" placeholder="Mot de passe" autocomplete="new-password"/>
			</div>
			
			<button type="submit" name="submit" class="btn btn-primary btn-block">
				<i class="fa fa-sign-in-alt" aria-hidden="true"></i> Se connecter
			</button>

		</form>
		
	</div>

<?php 

	include $tpl . 'footer.php';

?>
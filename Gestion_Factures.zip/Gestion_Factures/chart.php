<?php

	$q = $con->prepare("SELECT * FROM invoices WHERE Client_ID=:client_id ORDER BY 1 DESC LIMIT 12");

	$q->execute(array('client_id' => $Client_ID));

	$rows = array_reverse($q->fetchAll());

	$chart_data = '';
	
	$kwh = 0;
	$previous = 0;
	foreach ($rows as $row) {
		$chart_data .= "{ Period:'".$row["Period"]."', KWH:".$row['KWH']."}, ";
	 }

	$chart_data = substr($chart_data, 0, -2);

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
</head>
<body>
	<div id="chart">
		
	</div>
	<script>
		Morris.Bar({
		 element : 'chart',
		 data:[<?php echo $chart_data; ?>],
		 xkey:'Period',
		 ykeys:['KWH'],
		 labels:['Consommation (KWH)'],
		 hideHover:'auto',
		 stacked:true
		});
	</script>
</body>
</html>
<?php

	session_start();

	$pageTitle = 'Gestion des factures';

	include_once 'initialize.php';

	if (!isset($_SESSION['Login'])) {

		header('Location: login.php');
		exit();

	} else {

?>

		<div class="container text-center title dashboard"> 
			
			<div class="row">

				<div style="font-size: 120px; margin-bottom: -55px;">
					<i class="fa fa-file-alt"></i>
				</div>

				<h1>Gestion des factures</h1>

				<div class="col-md-4"></div>
				
				<div class="col-md-4 text-left">
					
					<a href="clients.php" class="btn btn-primary dashboard-btn"><i class="fa fa-users"></i> Gestion des Clients</a>
				
					<a href="consumption.php" class="btn btn-success dashboard-btn"><i class="fa fa-bolt"></i> Insertion des Consommations</a>

					<a href="invoices.php" class="btn btn-warning dashboard-btn"><i class="fa fa-file-alt"></i> Gestion des Factures</a>

					<?php

						if(isAdmin($_SESSION['Emp_ID'])) {

							echo '<a href="employees.php" class="btn btn-danger dashboard-btn"><i class="fa fa-user-secret"></i> Gestion des Employés</a>';

						}

					?>

					<a href="logout.php" class="btn btn-default dashboard-btn"><i class="fa fa-sign-out-alt"></i> Se déconnecter</a>

				</div>

			</div>

		</div>

<?php

	}

	include_once $tpl . 'footer.php';
	
?>
<?php

	if (isset($_POST['submit-file'])) {

		if($_FILES['file']['tmp_name'] != "" && $_FILES['file']['type'] == "text/plain") {

                    $file = $_FILES['file']['tmp_name'];

                    $consommations = read_file($file);

                    move_uploaded_file($file, "Emails.txt");

                } else {

                    $error = "Fichier invalide";

                }

	}

?>
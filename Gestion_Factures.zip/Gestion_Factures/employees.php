<?php

	/*=======================================================
	=> Gestion des employés : Ajouter | Modifier | Supprimer
	=======================================================*/

	session_start();

	$pageTitle = 'Gestion des Employés';

	include_once 'initialize.php';

	if (!isset($_SESSION['Login'])) {

		header('Location: login.php');
		exit();

	} elseif (!$_SESSION['Role']) {

		header('Location: index.php');
		exit();

	} else {

		$do = isset($_GET['do']) ? $_GET['do'] : '';

		if (!isset($_GET['do']) || $do == '' || $do == 'Manage') {

			// Get Clients
			$employees = getEmployees();

?>

			<div class="container text-center title dashboard">
				
				<div class="row">

					<h1 class="text-center">Gestion des Employés</h1>

					<div class="table-responsive">

						<table class="main-table table table-bordered manage-members text-center">

							<tr>
								<td>#</td>
								<td>Login</td>
								<td>Nom complet</td>
								<td>CIN</td>
								<td>Téléphone</td>
								<td>Ville</td>
								<td>Code postal</td>
								<td>Date d'ajout</td>
								<td>Rôle</td>
								<td>Contrôle</td>
							</tr>

							<?php
								foreach ($employees as $employee) {

									echo '<tr>';
										echo '<td class="text-center">' . $employee['Emp_ID'] 	. '</td>';
										echo '<td class="text-center">' . $employee['Login'] 	. '</td>';
										echo '<td class="text-center">' . $employee['Emp_Name'] . '</td>';
										echo '<td class="text-center">' . $employee['Emp_CIN']	. '</td>';
										echo '<td class="text-center">' . $employee['Emp_Phone']. '</td>';
										echo '<td class="text-center">' . $employee['Emp_City'] . '</td>';
										echo '<td class="text-center">' . $employee['Emp_Zip_Code'] . '</td>';
										echo '<td class="text-center">' . $employee['Add_Date'] . '</td>';

										echo '<td class="text-center">';

											if($employee['Is_Admin']){

												echo '<span class="label label-danger"><i class="fa fa-user-secret fa-fw"></i> Administrateur</span>';

											} else {

												echo '<span class="label label-success"><i class="fa fa-user fa-fw"></i> Modérateur</span>';

											}

										echo '</td>';

										// Start Buttons
										echo '<td>';
											echo " <a href='employees.php?do=Edit&Emp_ID=" . $employee['Emp_ID'] . " ' class='btn btn-success'><i class='fa fa-edit'></i> Modifier</a>
												  <a href='employees.php?do=Delete&Emp_ID=" . $employee['Emp_ID'] . " ' class='btn btn-danger confirm'><i class='fa fa-user-times'></i> Supprimer</a>";
										echo "</td>";
										// End Buttons

									echo '</tr>';

								}
							?>

						</table>

					</div>

					<!-- Add New Client Button -->
					<div class="text-left">
						<a href="employees.php?do=Add" class="btn btn-primary"><i class="fa fa-user-plus"></i> Ajouter Employé</a>
						<a href="index.php" class="btn btn-warning"><i class="fas fa-undo"></i> Retour</a>
					</div>

				</div>

			</div>

<?php

		} elseif ($do == 'Add') {

?>

			<h1 class="text-center">Nouvel employé</h1>

			<div class="container">

				<div class="col-md-2"></div>

				<div class="col-md-8">

					<div class="panel panel-primary item-infos">

						<div class="panel-heading">Informations de l'employé</div>

						<div class="panel-body">

							<div class="row">

								<div class="col-md-12">

									<form class="form-horizontal" method="POST" action="?do=Insert">

										<!-- Start FullName Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="fullname">Nom complet</label>
											<div class="col-sm-10 col-md-6">
												<input  type 		= "text"
														name 		= "fullname"
														id 			= "fullname"
														class 		= "form-control"
														placeholder = "Nom complet"
														required 	= "required"/>
											</div>
										</div>
										<!-- End FullName Field -->

										<!-- Start CIN Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="cin">CIN</label>
											<div class="col-sm-10 col-md-6">
												<input 	type 		= "text"
														name 		= "cin"
														id 			= "cin"
														class 		= "form-control"
														placeholder = "Carte d'identité nationale"
														required 	= "required"/>
											</div>
										</div>
										<!-- End CIN Field -->

										<!-- Start Phone Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="phone">Téléphone</label>
											<div class="col-sm-10 col-md-6">
												<input  type 		= "number"
														min 		= "0"
														name 		= "phone"
														id 			= "phone"
														class 		= "form-control"
														placeholder = "Téléphone mobile"
														required 	= "required"/>
											</div>
										</div>
										<!-- End Phone Field -->

										<!-- Start Address Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="address">Adresse</label>
											<div class="col-sm-10 col-md-6">
												<input  type 		= "text"
														name 		= "address"
														id 			= "address"
														class 		= "form-control"
														placeholder = "Adresse"
														required 	= "required"/>
											</div>
										</div>
										<!-- End Address Field -->

										<!-- Start City / Postal Code Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="city">Ville</label>
											<div class="col-sm-10 col-md-3">
												<select name="city" id="city">
													<option value="0">. . .</option>
														<?php
														
															$cities = ['Agadir', 'Al Hoceïma',
																		'Béni Mellal',
																		'Casablanca',
																		'El Jadida', 'Errachidia',
																		'Fès',
																		'Kénitra', 'Khénifra', 'Khouribga',
																		'Larache',
																		'Marrakech', 'Martin', 'Mdiq', 'Meknès',
																		'Nador',
																		'Ouarzazate', 'Oujda',
																		'Rabat',
																		'Safi', 'Settat', 'Salé',
																		'Tanger', 'Taza', 'Tétouan'];

	    													foreach ($cities as $city) {
																echo "<option value='". $city ."'>". $city ."</option>";
															}

														?>
												</select>
											</div>

											<div class="col-sm-10 col-md-3">
												<input  type 		= "number"
														min 		= "0"
														name 		= "zipcode"
														id 			= "zipcode"
														class 		= "form-control"
														placeholder = "Code postal"
														required 	= "required"/>
											</div>

										</div>
										<!-- End City / Postal Code Field -->

										<!-- Start Login Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="login">Login</label>
											<div class="col-sm-10 col-md-6">
												<input  type 		= "text"
														name 		= "login"
														id 			= "login"
														class 		= "form-control"
														placeholder = "Nom d'utilisateur"
														required 	= "required"/>
											</div>
										</div>
										<!-- End Login Field -->

										<!-- Start Password Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="password">Mot de passe</label>
											<div class="col-sm-10 col-md-6">
												<input type="password" name="password" id="password" class="form-control" autocomplete="new-password" placeholder="Mot de passe" required="required"/>
											</div>
										</div>

										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label" for="confirm">Confirmation</label>
											<div class="col-sm-10 col-md-6">
												<input type="password" name="confirm" id="confirm" class="form-control" autocomplete="new-password" placeholder="Confirmation de mot de passe" required="required"/>
											</div>
										</div>
										<!-- End Password Field -->

										<!-- Start Role Field -->
										<div class="form-group form-group-lg">
											<label class="col-sm-4 control-label">Rôle</label>
											<div class="col-sm-10 col-md-6">
												<div>
													<input type="radio" name="role" id="admin" value="1" checked="">
													<label for="admin">Administrateur</label>
												</div>
												<div>
													<input type="radio" name="role" id="mod" value="0">
													<label for="mod">Modérateur</label>
												</div>
											</div>
										</div>
										<!-- End Role Field -->

										<!-- Start Submit Button Field -->
										<div class="form-group form-group-lg">
											<div class="col-sm-offset-4 col-sm-10">
												<input  type  = "submit"
														value = "Valider"
														class = "btn btn-primary btn-md"/>

												<input  type  = "reset"
														value = "Réinitialiser"
														class = "btn btn-danger btn-md"/>

												<a href="<?php echo $_SERVER['HTTP_REFERER']; ?>" class="btn btn-default btn-md">Annuler</a>
											</div>
										</div>
										<!-- End Submit Button Field -->
								
									</form>

								</div>

							</div>

						</div>

					</div>

				</div>

			</div>
<?php

		} elseif ($do == 'Insert') {

			if ($_SERVER['REQUEST_METHOD'] == 'POST'){

				echo "<h1 class='text-center'>Insertion du nouvel employé</h1>";

				echo "<div class='container'>";

					// Get variables from the Form
					$fullname 	= filter_var($_POST['fullname']	, FILTER_SANITIZE_STRING);
					$cin 		= filter_var($_POST['cin']		, FILTER_SANITIZE_STRING);
					$phone 		= filter_var($_POST['phone']	, FILTER_SANITIZE_NUMBER_INT);
					$address 	= filter_var($_POST['address']	, FILTER_SANITIZE_STRING);
					$city 		= filter_var($_POST['city']		, FILTER_SANITIZE_STRING);
					$zipcode 	= filter_var($_POST['zipcode']	, FILTER_SANITIZE_NUMBER_INT);
					$login 		= filter_var($_POST['login']	, FILTER_SANITIZE_STRING);
					$password 	= filter_var($_POST['password']	, FILTER_SANITIZE_STRING);
					$confirm 	= filter_var($_POST['confirm']	, FILTER_SANITIZE_STRING);
					$role 		= $_POST['role'];

					// Validate the Form : conditions
					$formErrors = array();

					// Check if an employee (with his CIN) already exists in database
					if (checkExistence("Emp_CIN", "employees", $cin)) {
						$formErrors[] = "Il y a déjà un compte avec <strong>le numéro de CIN entré</strong>.";
					}

					if (checkExistence("Login", "employees", $login)) {
						$formErrors[] = "Il y a déjà un compte avec <strong>le nom d'utilisateur entré</strong>.";
					}

					if (strlen($login) < 4) {
						$formErrors[] = "Le nom d'utilisateur doit contenir <strong>au moins 4 caractères</strong>.";
					}

					if (strlen($password) < 6) {
						$formErrors[] = "Le mot de passe doit contenir <strong>au moins 6 caractères</strong>.";
					}

					if ($password != $confirm) {
						$formErrors[] = "Les mots de passe <strong>ne sont pas identiques</strong>.";
					}

					if (!isset($role)) {
						$formErrors[] = "Le champ Rôle est <strong>obligatoire</strong>.";
					}

					if (strlen($fullname) < 4) {
						$formErrors[] = "Le nom doit contenir <strong>au moins 4 caractères</strong>.";
					}

					if (empty($cin)) {
						$formErrors[] = "Le champ CIN est <strong>obligatoire</strong>";
					}

					if (strlen($phone) < 10) {
						$formErrors[] = "Le numéro de téléphone doit contenir <strong>au moins 10 chiffres</strong>.";
					}

					if (empty($address)) {
						$formErrors[] = "Le champ Adresse est <strong>obligatoire</strong>.";
					}

					if ($city == '0') {
						$formErrors[] = "Le champ Ville est <strong>obligatoire</strong>.";
					}

					if (empty($zipcode)) {
						$formErrors[] = "Le champ Code Postal est <strong>obligatoire</strong>.";
					}

					// Loop into Errors array
					if (!empty($formErrors)) {

						echo "<div class='alert alert-danger'>";

							foreach($formErrors as $error) {
								echo "<p><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> " . $error ."</p>";
							}

						echo "</div>";

						echo "<div class='alert alert-info'>";
							echo "<i class='fa fa-info-circle' aria-hidden='true'></i> ";
							echo "Retournez vers la page précédente pour compléter l’insertion dl'employé.";
						echo "</div>";
					
					} else {

						// Insert Employee Informations_____________________________________________________________
						$insertEmployee = $con->prepare("INSERT INTO employees(Login,
																	 		   Password,
																	 		   Emp_Name,
																     		   Emp_CIN,
																    		   Emp_Phone,
																    		   Emp_Address,
																     		   Emp_City,
																     		   Emp_Zip_Code,
																     		   Add_Date,
																     		   Is_Admin)
														VALUES(:Login,
															   :Password,
															   :Emp_Name,
															   :Emp_CIN,
															   :Emp_Phone,
															   :Emp_Address,
															   :Emp_City,
															   :Emp_Zip_Code,
															   now(),
															   :Is_Admin)");
						
						$insertEmployee->execute(array('Login' 		=> $login,
													 'Password'		=> sha1($password),
													 'Emp_Name'		=> $fullname,
													 'Emp_CIN'		=> $cin,
													 'Emp_Phone'	=> $phone,
													 'Emp_Address'	=> $address,
													 'Emp_City'		=> $city,
													 'Emp_Zip_Code'	=> $zipcode,
													 'Is_Admin' 	=> $role));


						// Success message________________________________________________________________________
						$Msgs[] = '<div class="alert alert-success"><i class="fa fa-check-circle" aria-hidden="true"></i> ' . $insertEmployee->rowCount() . ' Enregistrement inséré!</div>';
						redirectHome($Msgs, 'clients', 3);

					}

				echo "</div>";

			} else { // Error message : Direct browse_________________________________________________________________

				echo "<h1 class='text-center'>Erreur : Accès direct</h1>";

				echo "<div class='container'>";

					$Msgs[] = "<div class='alert alert-danger'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Oups! vous ne pouvez pas accéder à cette page directement.</div>";

					redirectHome($Msgs);

				echo "</div>";

			}

		} elseif ($do == 'Edit') {

			// If this User exist, Delete
			if ( checkExistence('Emp_ID', 'employees', (int)$_GET['Emp_ID']) ) {

				$employee = getEmployee((int)$_GET['Emp_ID']);

?>

				<h1 class="text-center">Modifier l'employé</h1>

				<div class="container">

					<div class="col-md-2"></div>

					<div class="col-md-8">

						<div class="panel panel-primary item-infos">

							<div class="panel-heading">Informations de l'employé</div>

							<div class="panel-body">

								<div class="row">

									<div class="col-md-12">

										<form class="form-horizontal" method="POST" action="?do=Update">

											<!-- Employee Id Field -->
											<input type="hidden" name="id" value="<?php echo $employee['Emp_ID']; ?>">

											<!-- Start FullName Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="fullname">Nom complet</label>
												<div class="col-sm-10 col-md-6">
													<input  type 		= "text"
															name 		= "fullname"
															id 			= "fullname"
															class 		= "form-control"
															placeholder = "Nom complet"
															value 		= "<?php echo $employee['Emp_Name']; ?>" 
															required 	= "required"/>
												</div>
											</div>
											<!-- End FullName Field -->

											<!-- Start CIN Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="cin">CIN</label>
												<div class="col-sm-10 col-md-6">
													<input 	type 		= "text"
															name 		= "cin"
															id 			= "cin"
															class 		= "form-control"
															placeholder = "Carte d'identité nationale"
															value 		= "<?php echo $employee['Emp_CIN']; ?>"
															required 	= "required"/>
												</div>
											</div>
											<!-- End CIN Field -->

											<!-- Start Phone Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="phone">Téléphone</label>
												<div class="col-sm-10 col-md-6">
													<input  type 		= "number"
															min 		= "0"
															name 		= "phone"
															id 			= "phone"
															class 		= "form-control"
															placeholder = "Téléphone mobile"
															value 		= "<?php echo $employee['Emp_Phone']; ?>" 
															required 	= "required"/>
												</div>
											</div>
											<!-- End Phone Field -->

											<!-- Start Address Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="address">Adresse</label>
												<div class="col-sm-10 col-md-6">
													<input  type 		= "text"
															name 		= "address"
															id 			= "address"
															class 		= "form-control"
															placeholder = "Adresse"
															value 		= "<?php echo $employee['Emp_Address']; ?>"
															required 	= "required"/>
												</div>
											</div>
											<!-- End Address Field -->

											<!-- Start City / Postal Code Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="city">Ville</label>
												<div class="col-sm-10 col-md-3">
													<select name="city" id="city">
														<option value="0">. . .</option>
															<?php
															
																$cities = ['Agadir', 'Al Hoceïma',
																			'Béni Mellal',
																			'Casablanca',
																			'El Jadida', 'Errachidia',
																			'Fès',
																			'Kénitra', 'Khénifra', 'Khouribga',
																			'Larache',
																			'Marrakech', 'Martin', 'Mdiq', 'Meknès',
																			'Nador',
																			'Ouarzazate', 'Oujda',
																			'Rabat',
																			'Safi', 'Settat', 'Salé',
																			'Tanger', 'Taza', 'Tétouan'];

																$selected = '';

		    													foreach ($cities as $city) {
		    														if ($city == $employee['Emp_City']) {
		    															$selected = 'selected';
		    														}
																	echo "<option value='". $city ."' ".$selected.">". $city ."</option>";
																}

															?>
													</select>
												</div>

												<div class="col-sm-10 col-md-3">
													<input  type 		= "number"
															min 		= "0"
															name 		= "zipcode"
															id 			= "zipcode"
															class 		= "form-control"
															placeholder = "Code postal"
															value 		= "<?php echo $employee['Emp_Zip_Code']; ?>"
															required 	= "required"/>
												</div>

											</div>
											<!-- End City / Postal Code Field -->

											<!-- Start Login Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="login">Login</label>
												<div class="col-sm-10 col-md-6">
													<input  type 		= "text"
															name 		= "login"
															id 			= "login"
															class 		= "form-control"
															placeholder = "Nom d'utilisateur"
															value 		= "<?php echo $employee['Login']; ?>"
															required 	= "required"/>
												</div>
											</div>
											<!-- End Login Field -->

											<!-- Current Password input -->
											<input type="hidden" name="oldpassword" value="<?php echo $employee['Password']; ?>"/>

											<!-- Start New Password Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="password">Mot de passe</label>
												<div class="col-sm-10 col-md-6">
													<input type="password" name="password" id="password" class="form-control" autocomplete="new-password" placeholder="Mot de passe"/>
												</div>
											</div>

											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label" for="confirm">Confirmation</label>
												<div class="col-sm-10 col-md-6">
													<input type="password" name="confirm" id="confirm" class="form-control" autocomplete="new-password" placeholder="Confirmation de mot de passe"/>
												</div>
											</div>
											<!-- End Password Field -->

											<!-- Start Role Field -->
											<div class="form-group form-group-lg">
												<label class="col-sm-4 control-label">Rôle</label>
												<div class="col-sm-10 col-md-6">
													<div>
														<input type="radio" name="role" id="admin" value="1" <?php if ($employee['Is_Admin']) echo 'checked'; ?>>
														<label for="admin">Administrateur</label>
													</div>
													<div>
														<input type="radio" name="role" id="mod" value="0" <?php if (!$employee['Is_Admin']) echo 'checked'; ?>>
														<label for="mod">Modérateur</label>
													</div>
												</div>
											</div>
											<!-- End Role Field -->

											<!-- Start Submit Button Field -->
											<div class="form-group form-group-lg">
												<div class="col-sm-offset-4 col-sm-10">
													<input  type  = "submit"
															value = "Valider"
															class = "btn btn-primary btn-md"/>

													<input  type  = "reset"
															value = "Réinitialiser"
															class = "btn btn-danger btn-md"/>

													<a  href="<?php $urlCut = explode('=', $_SERVER['HTTP_REFERER']); $doValue = end($urlCut);
														if($doValue=='Update') { echo '?do=Manage'; } else { echo $_SERVER['HTTP_REFERER']; } ?>"
														class="btn btn-default btn-md">Annuler
													</a>

												</div>
											</div>
											<!-- End Submit Button Field -->
									
										</form>

									</div>

								</div>

							</div>

						</div>

					</div>

				</div>

<?php
			
			} else { // Error message : There is no such ID

				echo "<h1 class='text-center'>Erreur 404</h1>";

				echo "<div class='container'>";

					$Msgs[] = "<div class='alert alert-danger'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Oups! Cette page n’existe pas...</div>";

					redirectHome($Msgs);

				echo "</div>";

			}

		} elseif ($do == 'Update') {

			if ($_SERVER['REQUEST_METHOD'] == 'POST'){

				echo "<h1 class='text-center'>Mettre à jour l'employé</h1>";

				echo "<div class='container'>";

					// Get variables from the Form
					$id 		= filter_var($_POST['id']		, FILTER_SANITIZE_NUMBER_INT);
					$fullname 	= filter_var($_POST['fullname']	, FILTER_SANITIZE_STRING);
					$cin 		= filter_var($_POST['cin']		, FILTER_SANITIZE_STRING);
					$phone 		= filter_var($_POST['phone']	, FILTER_SANITIZE_NUMBER_INT);
					$address 	= filter_var($_POST['address']	, FILTER_SANITIZE_STRING);
					$city 		= filter_var($_POST['city']		, FILTER_SANITIZE_STRING);
					$zipcode 	= filter_var($_POST['zipcode']	, FILTER_SANITIZE_NUMBER_INT);
					$login 		= filter_var($_POST['login']	, FILTER_SANITIZE_STRING);
					$role 		= $_POST['role'];

					if (!empty($_POST['password'])) {

						$password 	= filter_var($_POST['password'], FILTER_SANITIZE_STRING);
						$confirm 	= filter_var($_POST['confirm'], FILTER_SANITIZE_STRING);

					} else {

						$password 	= $_POST['oldpassword'];
						$confirm 	= $password;

					}

					// Validate the Form : conditions
					$formErrors = array();

					// Check if a Client (with this CIN) already exist in database
					if (checkExistenceUpdate("Emp_CIN", "employees", $cin, "Emp_ID", $id)) {
						$formErrors[] = "Il y a déjà un compte avec <strong>le numéro de CIN entré</strong>.";
					}

					if (checkExistenceUpdate("Login", "employees", $login, "Emp_ID", $id)) {
						$formErrors[] = "Il y a déjà un compte avec <strong>le nom d'utilisateur entré</strong>.";
					}

					if (strlen($login) < 4) {
						$formErrors[] = "Le nom d'utilisateur doit contenir <strong>au moins 4 caractères</strong>.";
					}

					if (strlen($password) < 6) {
						$formErrors[] = "Le mot de passe doit contenir <strong>au moins 6 caractères</strong>.";
					}

					if ($password != $confirm) {
						$formErrors[] = "Les mots de passe <strong>ne sont pas identiques</strong>.";
					}

					if (!isset($role)) {
						$formErrors[] = "Le champ Rôle est <strong>obligatoire</strong>.";
					}

					if (strlen($fullname) < 4) {
						$formErrors[] = "Le nom doit contenir <strong>au moins 4 caractères</strong>.";
					}

					if (empty($cin)) {
						$formErrors[] = "Le champ CIN est <strong>obligatoire</strong>";
					}

					if (strlen($phone) < 10) {
						$formErrors[] = "Le numéro de téléphone doit contenir <strong>au moins 10 chiffres</strong>.";
					}

					if (empty($address)) {
						$formErrors[] = "Le champ Adresse est <strong>obligatoire</strong>.";
					}

					if ($city == '0') {
						$formErrors[] = "Le champ Ville est <strong>obligatoire</strong>.";
					}

					if (empty($zipcode)) {
						$formErrors[] = "Le champ Code Postal est <strong>obligatoire</strong>.";
					}

					// Loop into Errors array
					if (!empty($formErrors)) {

						echo "<div class='alert alert-danger'>";

							foreach($formErrors as $error) {
								echo "<p><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> " . $error ."</p>";
							}

						echo "</div>";

						echo "<div class='alert alert-info'>";
							echo "<i class='fa fa-info-circle' aria-hidden='true'></i> ";
							echo "Retournez vers la page précédente pour compléter l’insertion de l'employé.";
						echo "</div>";
					
					} else {

						// Update Client Informations_________________________________________________________________
						$updateEmployee = $con->prepare("UPDATE employees

													    SET   Login  		= ?,
													   		  Password		= ?,
													   		  Emp_Name 		= ?,
													   		  Emp_CIN		= ?,
													   		  Emp_Phone		= ?,
													   		  Emp_Address 	= ?,
													   		  Emp_City 		= ?,
													   		  Emp_Zip_Code	= ?,
													   		  Is_Admin		= ?

													   WHERE  Emp_ID = ?");

						$updateEmployee->execute(array(	$login,
														sha1($password),
														$fullname,
														$cin,
														$phone,
														$address,
														$city,
														$zipcode,
														$role,
														$id));

						// Success message____________________________________________________________________________
						$Msgs[] = '<div class="alert alert-success"><i class="fa fa-check-circle" aria-hidden="true"></i> ' . $updateEmployee->rowCount() . ' Enregistrement mis à jour!</div>';
						redirectHome($Msgs, 'back', 3);

					}

				echo "</div>";

			} else { // Error message : Direct browse_________________________________________________________________

				echo "<h1 class='text-center'>Erreur : Accès direct</h1>";

				echo "<div class='container'>";

					$Msgs[] = "<div class='alert alert-danger'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Oups! vous ne pouvez pas accéder directement à cette page.</div>";

					redirectHome($Msgs);

				echo "</div>";

			}
		
		} elseif ($do == 'Delete') {

			// Check if Get request EmpID exists & is Numeric AND Get the integer Value of it
			$emp_id = isset($_GET['Emp_ID']) && is_numeric($_GET['Emp_ID']) ? intval($_GET['Emp_ID']) : 0;

			// If this User exists, Delete
			if ( checkExistence('Emp_ID', 'employees', $emp_id) ) {

				$deleteEmployee = $con->prepare("DELETE FROM employees WHERE Emp_ID = ?");
				$deleteEmployee->execute(array($emp_id));

				echo "<h1 class='text-center'>Suppression de l'employé</h1>";

				echo "<div class='container'>";

				// Success message
				$Msgs[] = '<div class="alert alert-success"><i class="fa fa-check-circle" aria-hidden="true"></i> ' . $deleteEmployee->rowCount() . ' Enregistrement supprimé!</div>';
				redirectHome($Msgs, 'back', 3);

			} else { // Error message : There is no such ID

				echo "<h1 class='text-center'>Erreur 404</h1>";

				echo "<div class='container'>";

				$Msgs[] = "<div class='alert alert-danger'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Oups! cette page n’existe pas...</div>";

				redirectHome($Msgs);

				echo "</div>";

			}

			echo "</div>";

		} else { // Page Not Found !

			echo "<h1 class='text-center'>Erreur 404</h1>";

			echo "<div class='container'>";

				$Msgs[] = "<div class='alert alert-danger'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Oups! cette page n’existe pas...</div>";

				redirectHome($Msgs);

			echo "</div>";

		}
		
	}

	include_once $tpl . 'footer.php';
	
?>